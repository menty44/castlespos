#ifndef _SETTING_H
#define	_SETTING_H

#ifdef	__cplusplus
extern "C" {
#endif

void Do_Setting(void);

#ifdef	__cplusplus
}
#endif

#endif	/* _SETTING_H */

