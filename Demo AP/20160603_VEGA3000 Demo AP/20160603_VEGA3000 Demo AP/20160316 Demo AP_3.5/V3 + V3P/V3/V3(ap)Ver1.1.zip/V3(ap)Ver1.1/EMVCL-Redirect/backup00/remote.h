#ifndef REMOTE_H
#define	REMOTE_H

#ifdef	__cplusplus
extern "C" {
#endif

int Remote(void);


#ifdef	__cplusplus
}
#endif

#endif	/* REMOTE_H */

