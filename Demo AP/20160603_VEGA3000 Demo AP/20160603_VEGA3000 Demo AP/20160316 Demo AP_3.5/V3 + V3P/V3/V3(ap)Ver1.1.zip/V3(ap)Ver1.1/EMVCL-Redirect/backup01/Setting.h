#ifndef _SETTING_H
#define	_SETTING_H

#ifdef	__cplusplus
extern "C" {
#endif

void Do_Setting(void);
void Wave2TransactionEnable(void);
void Wave2TransactionDisable(void);

#ifdef	__cplusplus
}
#endif

#endif	/* _SETTING_H */

